package es.tiernoparla.optativas.a;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

public class ValorTotal {

    public static void main(String[] args) {
        try {
            // Con esto cargamos el XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse("obras.xml");
            
            // Creamos el objeto XPath y la factoria
            XPathFactory xpathFactory = XPathFactory.newInstance();
            XPath xpath = xpathFactory.newXPath();
            
            // Con XPathExpression se establece la expresion que va a seguir
            XPathExpression expression = xpath.compile("//obra/precio/text()");
            
            // Con esto hacemos que recorra los nodos del xml
            NodeList nodo = (NodeList) expression.evaluate(document, XPathConstants.NODESET);

            double total = 0.0;
            for (int i = 0; i < nodo.getLength(); i++) {
                String precio = nodo.item(i).getNodeValue();
                double precioTotal = Double.parseDouble(precio);
                total += precioTotal;
            }
            // Imprimir el valor total
            System.out.println("El valor total de las obras es de: " + total);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}