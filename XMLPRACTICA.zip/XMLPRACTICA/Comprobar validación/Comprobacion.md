# Comprobación

### Octavio Jiménez, Rubén García, Dalia Ortiz y Jose Notario.

Para hacer la comprobación tanto de los archivos.dtd como de los archivos.xsd Hemos decidido usar un software diferente al VSCode.
La validación la vamos a hacer con **XML Copy Editor**.

![Software](./imagenes/software.png)

Para ello abrimos el programa.
![](imagenes/vacia.png)

Luego de abrirlo le damos a fichero abrir o seleccionamos el icono de la carpetita.
Y abrimos todos los archivos.xml

![archivos](imagenes/abiertos.png)


Ahora que tenemos los archivos abiertos podemos hacer la validación de dos formas. Por estructura de que este bien hecho el xml o que sea valido.
Para ellos usamos los ticks de arriba.


El azul es para la estructura:
![](imagenes/formado.png)
Y el verde para la validación:
![](imagenes/validar.png)

Ahora vamos a comprobar cada archivo xml.
### Autores.xml:
Primero comprobamos que se valide haciendo referencia al autores.dtd y al ser correcto nos aparece autores.xml is valid.
![](imagenes/autores1.png)

Ahora vamos a hacer la comprobación haciendo referencia a autores.xsd y al igual que en el caso anterior nos pone autores.xml is valid.
![](imagenes/autores2.png)

También podemos hacer ka validación haciendo referencia tanto al archivo.xsd como al archivo.dtd.
![](imagenes/autores3.png)

Para poner un ejemplo de error borramos las etiquetas estilo y vemos que nos da el error al validarlo y nos indica cuál es.
![](imagenes/error.png)

### Galerias.xsd:

![](imagenes/galerias.png)

### Obras.xsd:

![](imagenes/obras.png)


## Validación por VSCode

De igual manera, con la extensión de RedHat de XML para VSCode también podemos validar los xml, tal y como podemos ver a continuación

### Validación DTD:

![DTD](imagenes/dtd.png)

### Validación XSD:

![XSD](imagenes/xsd.png)
