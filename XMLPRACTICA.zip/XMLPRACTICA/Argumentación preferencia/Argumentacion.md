# Argumentación

### Octavio Jiménez, Rubén García, Dalia Ortiz y Jose Notario.

Bueno para estos casos particulares preferimos usar los **XSD** por el hecho de que definimos la estructura igual que haríamos con un **DTD** pero el **XSD** es más completo a la hora de validar porque puedes establecer reglas y restricciones lo que lo hace más flexible y capaz de definir mejor los valores que contenga el **XML**

Por poner un ejemplo en el de autores el año de nacimiento del autor hay un máximo de 2023 porque es el año en el que estamos y de mínimo el -3761 establecido como el año 3761 antes de Cristo esa restricción la podemos poner gracias al archivo xsd dado que con el dtd no hubieramos podido establecer esta restricción de rangos.